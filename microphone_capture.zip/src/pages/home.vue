<template>
  <f7-page name="home">
    <!-- Top Navbar -->
    <f7-navbar>
      <f7-nav-title>My App</f7-nav-title>
      <f7-nav-right>
        <f7-link
          icon-ios="f7:menu"
          icon-aurora="f7:menu"
          icon-md="material:menu"
          panel-open="right"
        ></f7-link>
      </f7-nav-right>
    </f7-navbar>
    <!-- Page content-->
    <f7-block-title class="text-align-center">Hello World!</f7-block-title>
    <f7-block>
      <f7-row>
        <f7-col></f7-col>
        <f7-col>
          <f7-button large small fill @click="repeatSound()"
            >Record sound!
          </f7-button>
          <f7-button large small fill @click="playSound()"
            >Play sound!
          </f7-button>
        </f7-col>
        <f7-col> </f7-col>
      </f7-row>
    </f7-block>
  </f7-page>
</template>

<script>
export default {
  setup() {
    let audio;
    let fileSystem;
    
    const isAndroid = () => {
      const userAgent = navigator.userAgent || navigator.vendor || window.opera;
      if (/android/i.test(userAgent)) return true;
      return false;
    };

    const isIos = () => {
      const userAgent = navigator.userAgent || navigator.vendor || window.opera;
      if (/iPad|iPhone|iPod/i.test(userAgent)) return true;
      return false;
    };

    const isMobile = () => window.cordova && (isAndroid() || isIos());

    const repeatSound = () => {
        audioinput.start({
          streamToWebAudio: true,
        });

        console.log(audioinput.getAudioContext().destination);
        console.log(audioinput.getAudioContext());
        console.log(JSON.stringify(audioinput.getAudioContext()));
        console.log(JSON.stringify(audioinput.getAudioContext().destination));
        // Connect the audioinput to the device speakers in order to hear the captured sound.
        audioinput.connect(audioinput.getAudioContext().destination);
        
        setTimeout(() => {
          audioinput.stop(() => {
            console.log("stopped");
          });
        }, 5000);


    }

    const recordSound = () => {
      if (isMobile() == true) {
        // audioinput.start({
        //   streamToWebAudio: true,
        // });

        // console.log(audioinput.getAudioContext().destination);
        // console.log(audioinput.getAudioContext());
        // console.log(JSON.stringify(audioinput.getAudioContext()));
        // console.log(JSON.stringify(audioinput.getAudioContext().destination));

        // setTimeout(() => {
        //   audioinput.stop(() => {
        //     console.log("stopped");
        //   });
        // }, 5000);

        // Connect the audioinput to the device speakers in order to hear the captured sound.
        // audioinput.connect(audioinput.getAudioContext().destination);

        // Get access to the file system
        window.requestFileSystem(
          window.TEMPORARY,
          5 * 1024 * 1024,
          function (fs) {
            console.log("Got file system: " + fs.name);
            console.log("Got file system: " + JSON.stringify(fs));
            console.log("Got file system: " + fs);
            fileSystem = fs;

            // Now you can initialize audio, telling it about the file system you want to use.
            var captureCfg = {
              sampleRate: 16000,
              bufferSize: 8192,
              channels: 1,
              format: audioinput.FORMAT.PCM_16BIT,
              audioSourceType: audioinput.AUDIOSOURCE_TYPE.DEFAULT,
              fileUrl: cordova.file.cacheDirectory,
            };

            // Initialize the audioinput plugin.
            window.audioinput.initialize(captureCfg, function () {
              // Now check whether we already have permission to access the microphone.
              window.audioinput.checkMicrophonePermission(function (
                hasPermission
              ) {
                if (hasPermission) {
                  console.log("Already have permission to record.");
                } else {
                  // Ask the user for permission to access the microphone
                  window.audioinput.getMicrophonePermission(function (
                    hasPermission,
                    message
                  ) {
                    if (hasPermission) {
                      console.log("User granted permission to record.");
                    } else {
                      console.warn("User denied permission to record.");
                    }
                  });
                }
              });
            });
          },
          function (e) {
            console.log("Couldn't access file system: " + e.message);
          }
        );

        // Later, when we want to record to a file...
        var captureCfg = {
          fileUrl: cordova.file.cacheDirectory + "temp.wav",
        };

        console.log(captureCfg.fileUrl)

        // Start the capture.
        audioinput.start(captureCfg);

        setTimeout(() => {
          // ...and when we're ready to stop recording.
          audioinput.stop(function (url) {
            console.log(url)
            console.log(JSON.stringify(url))

            // Now you have the URL (which might be different to the one passed in to audioinput.start())
            // You might, for example, read the data into a blob.
            window.resolveLocalFileSystemURL(
              captureCfg.fileUrl,
              function (tempFile) {
                tempFile.file(function (tempWav) {
                  var reader = new FileReader();
                  reader.onloadend = function (e) {
                    // Create the blob from the result.
                    var blob = new Blob([new Uint8Array(this.result)], {
                      type: "audio/wav",
                    });
                    // Delete the temporary file.
                    tempFile.remove(function (e) {
                      console.log("temporary WAV deleted");
                    }, fileError);
                    // Do something with the blob.
                    console.log(blob)
                    doSomethingWithWAVData(blob);
                  };
                  reader.readAsArrayBuffer(tempWav);
                });
              },
              function (e) {
                console.log(
                  "Could not resolveLocalFileSystemURL: " + JSON.stringify(e)
                );
              }
            );
          });
        }, 5000);
      } else {
        navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
          const mediaRecorder = new MediaRecorder(stream);
          mediaRecorder.start();

          const audioChunks = [];

          mediaRecorder.addEventListener("dataavailable", (event) => {
            audioChunks.push(event.data);
          });

          mediaRecorder.addEventListener("stop", () => {
            const audioBlob = new Blob(audioChunks);
            const audioUrl = URL.createObjectURL(audioBlob);
            audio = new Audio(audioUrl);
          });

          setTimeout(() => {
            mediaRecorder.stop();
            console.log(audioChunks);
          }, 5000);
        });
      }
    };

    const playSound = () => {
      if (isMobile() == true) {
        console.log("play mobile");
      } else {
        audio.play();
      }
    };

    return {
      recordSound,
      repeatSound,
      playSound,
    };
  },
};
</script>
